/**
 * Copyright(c) 2021 All rights reserved by Jungho Kim in Myungji University.
 */
package Framework;

import Components.Department.MiddleFilter;
import Components.Precourse.AddFilter;
import Components.Sink.SinkFilter;
import Components.Source.SourceFilter;

public class LifeCycleManager {
    public static void main(String[] args) {
        try {
            CommonFilter sourceFilter = new SourceFilter("Students.txt");
            CommonFilter sinkFilter = new SinkFilter("Output.txt");
            CommonFilter csFilter = new MiddleFilter("CS");
            CommonFilter firstPreCourse = new AddFilter("12345");
            CommonFilter secondPreCourse = new AddFilter("23456");
            
            sourceFilter.connectOutputTo(csFilter);
            csFilter.connectOutputTo(firstPreCourse);
            firstPreCourse.connectOutputTo(secondPreCourse);
            secondPreCourse.connectOutputTo(sinkFilter);
            
            Thread sourceThread = new Thread(sourceFilter);
            Thread sinkThread = new Thread(sinkFilter);
            Thread departmentThread = new Thread(csFilter);
            Thread firstPreCourseThread = new Thread(firstPreCourse);
            Thread secondPreCourseThread = new Thread(secondPreCourse);
            
            sourceThread.start();
            sinkThread.start();
            departmentThread.start();
            firstPreCourseThread.start();
            secondPreCourseThread.start();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
