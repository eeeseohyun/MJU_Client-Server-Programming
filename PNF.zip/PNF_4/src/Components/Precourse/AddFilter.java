package Components.Precourse;

import java.io.IOException;

import Framework.CommonFilterImpl;

public class AddFilter extends CommonFilterImpl{
	private String string;
	public AddFilter(String string) {
		this.string = string;
	}
	 @Override
	    public boolean specificComputationForFilter() throws IOException {
			 int startCheckBlank = 3;
			 int numberOfEmpty = 0;
			 int byte_read = 0;
			 byte[] outputStream = new byte[64];
		 	 int idx = 0;
			 boolean checkHasPreCourse = false;
			 
			 while(true) {
				 byte_read = in.read();
				 if(byte_read == -1) return true;
				 while(byte_read!=13 && byte_read != -1) {
					 if(byte_read == ' ') numberOfEmpty++;
					 outputStream[idx] =  (byte) byte_read; 
					 if(numberOfEmpty>startCheckBlank&&outputStream[idx]==string.charAt(4) && outputStream[idx-1] ==string.charAt(3) && outputStream[idx-2]==string.charAt(2)&& outputStream[idx-3]==string.charAt(1)&&outputStream[idx-4]==string.charAt(0)) checkHasPreCourse=true;
					 idx++;
					 byte_read = in.read();
				 }
				 if(byte_read==13) {
					 byte_read = in.read();
				 }
				 if(checkHasPreCourse==true) {
					 for(int i=0; i<idx; i++) {
						 out.write(outputStream[i]);
					 }
					 out.write('\r'); // 캐리지 리턴 추가
					 out.write('\n'); // 개행 추가
				 }
				

				 idx=0;
				 checkHasPreCourse=false;
				 numberOfEmpty=0;
				 byte_read = 0;
		 }
	} 
}
