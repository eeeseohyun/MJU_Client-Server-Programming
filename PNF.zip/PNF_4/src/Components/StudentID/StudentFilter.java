package Components.StudentID;

import java.io.IOException;

import Framework.CommonFilterImpl;

public class StudentFilter extends CommonFilterImpl{
	private String studentId;
	public StudentFilter(String studentId) {
		this.studentId = studentId;
	}
    @Override
    public boolean specificComputationForFilter() throws IOException {
        int idx = 0;
        byte[] buffer = new byte[64];
        boolean isStudentId = false;
        int byte_read = 0;
        
        while(true) {          
        	byte_read = in.read();
        	
            while(byte_read != '\n' && byte_read != -1 ) {
            	buffer[idx] = (byte) byte_read;
            	if(idx==3 && buffer[2]==studentId.charAt(0) && buffer[3]==studentId.charAt(1)) isStudentId = true; 
            	idx++;
            	byte_read = in.read();
            }
            
            if(isStudentId == true) {
            	for(int i = 0; i<idx; i++) 
                    out.write((char)buffer[i]);
            	isStudentId =false;
            }
          
            if (byte_read == -1) return true;
            buffer = new byte[64];
            idx = 0;
            byte_read = 0;
        }
    }  
}
