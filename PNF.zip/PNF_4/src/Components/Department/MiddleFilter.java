/**
 * Copyright(c) 2021 All rights reserved by Jungho Kim in Myungji University.
 */
package Components.Department;

import java.io.IOException;
import Framework.CommonFilterImpl;

public class MiddleFilter extends CommonFilterImpl{
	private String department;
	public MiddleFilter(String department) {
		this.department = department;
	}
    @Override
    public boolean specificComputationForFilter() throws IOException {
    	int checkBlank = 3; 
        int numOfBlank = 0;
        int idx = 0;
        byte[] buffer = new byte[1000];
        boolean isnotDepartmnet = false;    
        int byte_read = 0;
        
        while(true) {          
        	byte_read = in.read();
        	// check "CS" on byte_read from student information
            while(byte_read != 13 && byte_read != -1) {
            	System.out.println(idx +" "+ byte_read);
                if(byte_read == ' ') numOfBlank++;
                if(byte_read != -1) buffer[idx] = (byte)byte_read;
                if(numOfBlank == checkBlank && buffer[idx-1] == department.charAt(0) && buffer[idx] == department.charAt(1))
                isnotDepartmnet = true;
                byte_read = in.read();
                idx++;
            }      
            if(isnotDepartmnet == false) {
                for(int i = 0; i<idx; i++) 
                    out.write((char)buffer[i]);
            }
			 out.write('\r'); // 캐리지 리턴 추가
			 out.write('\n'); // 개행 추가
            if(isnotDepartmnet == true) {
            	isnotDepartmnet = false;
            }
            if (byte_read == -1) return true;
            idx = 0;
            numOfBlank = 0;
            buffer = new byte[1000];
            byte_read = '\0';
        }
    }  
}
