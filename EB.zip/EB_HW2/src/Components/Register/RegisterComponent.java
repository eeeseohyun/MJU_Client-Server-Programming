package Components.Register;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class RegisterComponent {
	protected ArrayList<Register> vRegister;
	
	public RegisterComponent(String registerFileName) throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new FileReader(registerFileName));
		this.vRegister = new ArrayList<Register>();
		while(bufferedReader.ready()) {
			String registerInfo = bufferedReader.readLine();
			if(!registerInfo.equals("")) this.vRegister.add(new Register(registerInfo));
		}
		bufferedReader.close();
	}
	public RegisterComponent() {
		this.vRegister = new ArrayList<Register>();
	}
	public ArrayList<Register> getRegisterList(){
		return vRegister;
	}
}
