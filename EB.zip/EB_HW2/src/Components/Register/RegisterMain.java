package Components.Register;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import Components.Course.CourseComponent;
import Components.Student.StudentComponent;
import Framework.Event;
import Framework.EventId;
import Framework.EventQueue;
import Framework.RMIEventBus;

public class RegisterMain {

	public static void main(String args[]) throws IOException, NotBoundException{
		RMIEventBus eventBus = (RMIEventBus) Naming.lookup("EventBus");
		long componentId = eventBus.register();
		System.out.println("**RegisterMain(ID:" + componentId + ") is successfully registered. \n");
		RegisterComponent registerList = new RegisterComponent("C:\\Users\\User\\eclipse-workspace\\EB_HW2\\src\\Registers.txt");
		StudentComponent studentList = new StudentComponent("C:\\Users\\User\\eclipse-workspace\\EB_HW2\\src\\Students.txt");
		CourseComponent courseList = new CourseComponent("C:\\Users\\User\\eclipse-workspace\\EB_HW2\\src\\Courses.txt");
		Event event = null;
		boolean done = false;
		while (!done) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			EventQueue eventQueue = eventBus.getEventQueue(componentId);
			for (int i = 0; i < eventQueue.getSize(); i++) {
				registerList = new RegisterComponent("C:\\Users\\User\\eclipse-workspace\\EB_HW2\\src\\Registers.txt");
				studentList = new StudentComponent("C:\\Users\\User\\eclipse-workspace\\EB_HW2\\src\\Students.txt");
				courseList = new CourseComponent("C:\\Users\\User\\eclipse-workspace\\EB_HW2\\src\\Courses.txt");
				event = eventQueue.getEvent();
				switch (event.getEventId()) {
				case Register:
					printLogEvent("Get", event);
					eventBus.sendEvent(new Event(EventId.ClientOutput, makeRegister(registerList,courseList,studentList, event.getMessage())));
					break;
				case ListApply:
					printLogEvent("Get", event);
					eventBus.sendEvent(new Event(EventId.ClientOutput, getApply(event.getMessage())));
					break;
				default:
					break;
				}
			}
	}
}

	private static String getApply(String message) throws IOException {
		RegisterComponent registerList = new RegisterComponent("C:\\Users\\User\\eclipse-workspace\\EB_HW2\\src\\Registers.txt");
		String Result = "";
		ArrayList<Register> fileRegi = registerList.getRegisterList();
		for(int i=0; i<fileRegi.size();i++) {
			if(fileRegi.get(i).getStudentId().equals(message)) {
				Result+=fileRegi.get(i).getStudentId()+ " "+ fileRegi.get(i).getCourseId()+"\n";
			}
		}
		return Result;
	}

	private static String makeRegister(RegisterComponent registerList, CourseComponent courseList, StudentComponent studentList, String RegiInfo) {
		  StringTokenizer stringTokenizer = new StringTokenizer(RegiInfo);
		  String studentId = stringTokenizer.nextToken();
		  String courseId=(stringTokenizer.nextToken());
		if(!checkStudent(studentList,studentId)) {
			return "this student is not existed.";
		}
		if(!checkCourse(courseList,courseId)) {
			return "this course is not existed.";
		}
		if(!checkPreCourse(studentList,courseList,studentId,courseId)) {
			return "this student is not registered precourse.";
		}
		String filePath = "C:\\Users\\User\\eclipse-workspace\\EB_HW2\\src\\Registers.txt";
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(new FileWriter(filePath,true));
			writer.newLine();
			writer.write(RegiInfo);
			writer.newLine();
			writer.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return "success";
	}

	private static boolean checkPreCourse(StudentComponent studentList, CourseComponent courseList, String studentId,
			String courseId) {
		int num = studentList.findRegisteredStudentNumber(studentId);
		ArrayList<String> precourse=studentList.getStudentList().get(num).getCompletedCourses();
		int num2 = courseList.findRegisteredCourseNumber(courseId);
		ArrayList<String> precourse2 =courseList.getCourseList().get(num2).getPreCourseList();
		for(int i=0; i<precourse2.size();i++) {
			if(!precourse.contains(precourse2.get(i))) {
				return false;
			}
		}
		return true;
	}
		
	private static boolean checkCourse(CourseComponent courseList, String courseId) {
		if(courseList.isRegisteredCourse(courseId)) {
			return true;
		}
		return false;
	}

	private static boolean checkStudent(StudentComponent studentList, String studentId) {
		if(studentList.isRegisteredStudent(studentId)) {
			return true;
		}
		return false;
		
	}

	private static void printLogEvent(String comment, Event event) {
		System.out.println(
				"\n** " + comment + " the event(ID:" + event.getEventId() + ") message: " + event.getMessage());
	}
}
