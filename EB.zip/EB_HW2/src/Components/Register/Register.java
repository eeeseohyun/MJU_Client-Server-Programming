package Components.Register;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class Register {
	protected String studentId;
	protected String courseId;
	
	public Register(String inputString) {
		  StringTokenizer stringTokenizer = new StringTokenizer(inputString);
		  this.studentId = stringTokenizer.nextToken();
		  this.courseId= stringTokenizer.nextToken();
	}
	public String getStudentId() {
		return studentId;
	}
	public String getCourseId() {
		return courseId;
	}
}
