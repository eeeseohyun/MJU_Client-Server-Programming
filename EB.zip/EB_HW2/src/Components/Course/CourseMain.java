/**
 * Copyright(c) 2021 All rights reserved by Jungho Kim in MyungJi University 
 */
package Components.Course;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.util.ArrayList;

import Components.Student.Student;
import Framework.Event;
import Framework.EventId;
import Framework.EventQueue;
import Framework.RMIEventBus;

public class CourseMain {
	public static void main(String[] args) throws FileNotFoundException, IOException, NotBoundException {
		RMIEventBus eventBus = (RMIEventBus) Naming.lookup("EventBus");
		long componentId = eventBus.register();
		System.out.println("CourseMain (ID:" + componentId + ") is successfully registered...");

		CourseComponent coursesList = new CourseComponent("C:\\Users\\User\\eclipse-workspace\\EB_HW2\\src\\Courses.txt");
		Event event = null;
		boolean done = false;
		while (!done) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			EventQueue eventQueue = eventBus.getEventQueue(componentId);
			for (int i = 0; i < eventQueue.getSize(); i++) {
				coursesList = new CourseComponent("C:\\Users\\User\\eclipse-workspace\\EB_HW2\\src\\Courses.txt");
				event = eventQueue.getEvent();
				switch (event.getEventId()) {
				case ListCourses:
					printLogEvent("Get", event);
					eventBus.sendEvent(new Event(EventId.ClientOutput, makeCourseList(coursesList)));
					break;
				case RegisterCourses:
					printLogEvent("Get", event);
					eventBus.sendEvent(new Event(EventId.ClientOutput, registerCourse(coursesList, event.getMessage())));
					break;
				case DeleteCourses:
					printLogEvent("Get", event);
					eventBus.sendEvent(new Event(EventId.ClientOutput, deleteCourse(coursesList, event.getMessage())));
					break;
				case QuitTheSystem:
					eventBus.unRegister(componentId);
					done = true;
					break;
				default:
					break;
				}
			}
		}
	}
	private static String deleteCourse(CourseComponent coursesList, String courseId) {
		if(!coursesList.isRegisteredCourse(courseId)) {
			return "This course don't exist.";
		}
		int courseNum = coursesList.findRegisteredCourseNumber(courseId);
		coursesList.deleteCourse(courseNum);
		deleteCourseFile(coursesList);
		return "This course is successfully deleted";
	}
	private static void deleteCourseFile(CourseComponent coursesList) {
		ArrayList<Course> vCourse = coursesList.getCourseList();
		String filepath = "C:\\Users\\User\\eclipse-workspace\\EB_HW2\\src\\Courses.txt";
		try {
			BufferedWriter flushWriter = new BufferedWriter(new FileWriter(filepath));
			flushWriter.write("");
			flushWriter.close();
			BufferedWriter writer = new BufferedWriter(new FileWriter(filepath));
			for(int i=0; i<vCourse.size(); i++) {
				writer.write(vCourse.get(i).getString());
				writer.newLine();
				writer.newLine();
			}
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static String registerCourse(CourseComponent coursesList, String message) {
		Course course = new Course(message);
		if (!coursesList.isRegisteredCourse(course.courseId)) {
			coursesList.vCourse.add(course);
			addCourseFile(course);
			return "This course is successfully added.";
		} else
			return "This course is already registered.";
	}
	private static void addCourseFile(Course course) {
		String filePath = "C:\\Users\\User\\eclipse-workspace\\EB_HW2\\src\\Courses.txt";
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(new FileWriter(filePath,true));
			writer.newLine();
			writer.write(course.getString());
			writer.newLine();
			writer.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	private static String makeCourseList(CourseComponent coursesList) {
		String returnString = "";
		for (int j = 0; j < coursesList.vCourse.size(); j++) {
			returnString += coursesList.getCourseList().get(j).getString() + "\n";
		}
		return returnString;
	}
	private static void printLogEvent(String comment, Event event) {
		System.out.println(
				"\n** " + comment + " the event(ID:" + event.getEventId() + ") message: " + event.getMessage());
	}
}
