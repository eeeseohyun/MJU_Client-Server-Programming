
import java.util.StringTokenizer;

public class InCorrectAccessException extends Exception {
	private String studentId;
	private String password;
	public InCorrectAccessException(String errorMessage) {
		super(errorMessage);
	}
	public InCorrectAccessException(String errorMessage,String accountInfo){
		super(errorMessage);
		 StringTokenizer stringTokenizer = new StringTokenizer(accountInfo);
	    	this.studentId = stringTokenizer.nextToken();
	    	this.password = stringTokenizer.nextToken();
	}
	
	public void showAccountInfo (){
		System.out.println("입력하신 정보\n"+"studentID: "+studentId+"\n"+"password: "+password);
	}
	public void recommend() {
		System.out.println("다시 로그인 해보십시오.");
	}
}
