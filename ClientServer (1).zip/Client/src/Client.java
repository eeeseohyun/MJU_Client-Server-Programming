import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.SecretKey;

public class Client {
	private static BufferedReader objReader = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) {
		ServerIF server;
		try {
			server = (ServerIF)Naming.lookup("Server");
			run(server);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (NotBoundException e) {
			e.printStackTrace();
		}
		
	}
	public static void run(ServerIF server) {
			System.out.println("***************** MENU *****************\n"+"1.login");
			String sChoice=null;
			try {
				sChoice = objReader.readLine().trim();
				if(sChoice.equals("1")) {
					SecretKey requestToken = login(server);
					look(server,requestToken);
				}else{
					System.out.println("잘못된 값을 입력하셨습니다.\n"+"다시 시도하세요.");
					run(server);
				}
			} catch (IOException e) {
				e.printStackTrace();
				run(server);
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
				run(server);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				run(server);
			}
	}
	private static SecretKey login(ServerIF server) throws IOException, NoSuchAlgorithmException {
		SecretKey requestToken = null;
		try {
			System.out.println("학번과 비밀번호를 입력하세요\n"+"학번: ");
			String accountInfo = inputAccountData();
			requestToken = server.login(requestToken,accountInfo);
		} catch (RemoteException e) {
			e.printStackTrace();
			run(server);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			run(server);
		} catch (InCorrectAccessException e) {
			e.printStackTrace();
			e.showAccountInfo();
			run(server);
		}
		return requestToken;
	}
	public static void look(ServerIF server,SecretKey requestToken) throws IOException,  SQLException {
		printLook();
		String choice = objReader.readLine().trim();
			try {
				switch(choice) {
			case "1":
				lookStudents(requestToken,server);
				break;
			case "2":
				lookCourses(requestToken,server);
				break;
			case "3":
				addStudents(requestToken,server);
				break;
			case "4":
				addCourses(requestToken,server);
				break;
			case "5":
				deleteStudent(requestToken,server);
				break;
			case "6":
				deleteCourse(requestToken,server);
				break;
			case "7":
				courseRegistration(requestToken,server);
				break;
			case "8":
				System.exit(0);
			default:
				System.out.println("잘못된 값을 입력하셨습니다.\n"+"다시 시도하세요.");
				look(server,requestToken);
			}
			}catch (InCorrectAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				e.recommend();
				look(server,requestToken);
			}
			look(server,requestToken);
	}
	private static String inputAccountData() throws IOException {
		String studentID= objReader.readLine().trim();
		while(studentID.length()!=8) {
			System.out.println("형식이 맞지 않습니다.\n"+"다시 시도하세요.");
			System.out.println("학번을 입력하세요: ");
			studentID= objReader.readLine().trim();
		}
		System.out.print("비밀번호: ");
		String password= objReader.readLine().trim();
		String accountInfo = studentID+" "+password;
		return accountInfo;
	}


	private static void courseRegistration(SecretKey requestToken, ServerIF server) throws IOException{
		System.out.println("학번을 입력하세요: ");
		String studentId = objReader.readLine().trim();
		while(studentId.length()!=8) {
			System.out.println("형식이 맞지않습니다.\n"+"다시 입력하세요.");
			System.out.println("학번을 입력하세요: ");
			studentId = objReader.readLine().trim();
		}
		System.out.println("과목 번호를 입력하세요: ");
		String courseId = objReader.readLine().trim();
		RegistrateCourse registrateCourse = new RegistrateCourse(courseId+" "+studentId);
		try {
			server.Registrate(requestToken,registrateCourse);
			showRegistratedCourse(requestToken, studentId, server);
		} catch (InCorrectAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.recommend();
			courseRegistration(requestToken,server);
		} catch (InvalidRegistrationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("courseID : "+e.getId());
			courseRegistration(requestToken,server);
		}
		
	}

	public static void printLook() {
		System.out.println("***************** MENU *****************");
		System.out.println("1. List Students\n"
				+ "2. List Courses\n"
				+ "3. add Students\n"
				+ "4. add Courses\n"
				+ "5. delete Students\n"
				+ "6. delete Courses\n"
				+ "7. course Registration\n"
				+ "8. exit");
	}

	private static void lookStudents(SecretKey requestToken, ServerIF server) throws InCorrectAccessException, FileNotFoundException, IOException, SQLException {
		ArrayList<Student> str;
		str = server.getAllStudentData(requestToken);
		System.out.println("List Students : ");
		for(int i=0; i<str.size();i++) {
			System.out.println(str.get(i).toString());
		}
	}
	private static void lookCourses(SecretKey requestToken, ServerIF server) throws InCorrectAccessException, IOException {
		ArrayList<Course> str;
		str = server.getAllCourseData(requestToken);
		System.out.println("List Courses : ");
		for(int i=0; i<str.size();i++) {
			System.out.println(str.get(i).toString());
		}
	}
	private static void addStudents(SecretKey responseToken,ServerIF server) throws IOException, InCorrectAccessException {
		String studentInfo=null;
		System.out.println("학번: ");
		String studentNum = objReader.readLine().trim();
		while(studentNum.length()!=8) {
			System.out.println("형식이 맞지않습니다.\n"+"다시 입력하세요.");
			System.out.println("학번: ");
			studentNum = objReader.readLine().trim();
		}
		System.out.println("비밀번호: ");
		String password = objReader.readLine().trim();
		System.out.println("이름: ");
		String studentName = objReader.readLine().trim();
		System.out.println("학과: ");
		String department = objReader.readLine().trim();
		System.out.println("수강과목: ");
		String beforeSemesterCourse = objReader.readLine().trim();
		studentInfo = studentNum+" "+password+" "+studentName+" "+department+" "+ beforeSemesterCourse ;
		Student student = new Student(studentInfo);
		server.addStudent(responseToken,student);
		System.out.println("Sucess");
	}
	private static void addCourses(SecretKey requestToken, ServerIF server) throws IOException, InCorrectAccessException {
		String courseInfo=null;
		System.out.println("강좌번호: ");
		String courseNum = objReader.readLine().trim();
		System.out.println("교수명: ");
		String professorName = objReader.readLine().trim();
		System.out.println("강좌명: ");
		String courseName = objReader.readLine().trim();
		System.out.println("선수과목: ");
		String preCourse = objReader.readLine().trim();
		courseInfo = courseNum+" "+professorName+" "+courseName+" "+ preCourse;
		Course courseObj = new Course(courseInfo);
		server.addCourses(requestToken,courseObj);
		System.out.println("Sucess");
	}
	private static void deleteStudent(SecretKey requestToken, ServerIF server) throws IOException, InCorrectAccessException {
		System.out.print("학번을 입력하세요:");
		String studentId = objReader.readLine().trim();
		while(studentId.length()!=8) {
			System.out.println("형식이 맞지않습니다.\n"+"다시 입력하세요.");
			System.out.println("학번을 입력하세요: ");
			studentId = objReader.readLine().trim();
		}
		try {
			server.deleteStudent(requestToken,studentId);
		} catch (InvalidRegistrationException e) {
			e.printStackTrace();
			System.out.println("studentID : "+e.getId());
			deleteStudent(requestToken,server);
		}
	}
	private static void deleteCourse(SecretKey requestToken, ServerIF server) throws IOException, InCorrectAccessException {
		System.out.print("과목 번호를 입력하세요:");
		String courseNum = objReader.readLine().trim();
		try {
			server.deleteCourse(requestToken,courseNum);
		} catch (InvalidRegistrationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("courseID : "+e.getId());
			deleteCourse(requestToken,server);
		}
	}
	private static void showRegistratedCourse(SecretKey requestToken,String studentId,ServerIF server) throws InCorrectAccessException, RemoteException {
		ArrayList<RegistrateCourse> registratedCourses;
		registratedCourses =server.showRegistrate(requestToken,studentId);
		System.out.println("***************** 수강신청 내역 *****************");
		for(int i=0; i<registratedCourses.size();i++) {
			System.out.println(registratedCourses.get(i).toString());
		}
	}


}
