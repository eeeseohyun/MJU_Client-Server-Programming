
import java.io.Serializable;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Course implements Serializable{
	private static final long serialVersionUID = 1L;
	protected String CourseID;
	protected String ProfessorFirstName;
	protected String CourseName;
	protected ArrayList<String> preCourse;
	
	public Course(String inputString){
		StringTokenizer stringTokenizer = new StringTokenizer(inputString);
		this.CourseID = stringTokenizer.nextToken();
		this.ProfessorFirstName =stringTokenizer.nextToken();
		this.CourseName = stringTokenizer.nextToken();
		this.preCourse = new ArrayList<String>();
		while(stringTokenizer.hasMoreTokens()) {
			this.preCourse.add(stringTokenizer.nextToken());
		}
	}
	public void setCourseInfo(String inputString) {
		StringTokenizer stringTokenizer = new StringTokenizer(inputString);
		this.CourseID = stringTokenizer.nextToken();
		this.ProfessorFirstName =stringTokenizer.nextToken();
		this.CourseName = stringTokenizer.nextToken();
	}
	public void setAllCourse(String inputString){
		StringTokenizer stringTokenizer = new StringTokenizer(inputString);
		this.preCourse = new ArrayList<String>();
		while(stringTokenizer.hasMoreTokens()) {
			this.preCourse.add(stringTokenizer.nextToken());
		}
	}
	public String toString() {
		String stringReturn = this.CourseID + " " + this.ProfessorFirstName + " " + this.CourseName;
        for (int i = 0; i < this.preCourse.size(); i++) {
            stringReturn = stringReturn + " " + this.preCourse.get(i).toString();
        }
        return stringReturn;
	}
}
