
import java.util.ArrayList;

public class InvalidRegistrationException extends Exception{
	private String Id;
	public InvalidRegistrationException(String errorMessage) {
		super(errorMessage);
	}
	public InvalidRegistrationException(String Message, String Id) {
		super(Message);
		this.Id = Id;
	}
	
	public String getId() {
		return this.Id;
	}
}
