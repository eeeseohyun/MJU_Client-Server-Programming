
import java.io.Serializable;
import java.util.StringTokenizer;

public class RegistrateCourse implements Serializable {
	private static final long serialVersionUID = 1L;
	protected String courseId;
	protected String studentId;
	
	public RegistrateCourse(String inputString) {
		StringTokenizer stringTokenizer = new StringTokenizer(inputString);
		this.courseId = stringTokenizer.nextToken();
		this.studentId =stringTokenizer.nextToken();
	}
	public String toString() {
		String stringReturn = this.courseId + " " + this.studentId;
		return stringReturn;
	}
}
