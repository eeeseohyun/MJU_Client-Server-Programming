
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class StudentDao {
	public DatabaseConnection database;
	public StudentDao() {
		this.database = new DatabaseConnection(); 
	}
	public ArrayList<Student> getAllStudentData(String sql, String completedCourseSql) {
		ArrayList<Student> arr = new ArrayList<Student>();
		Connection con = null;
		Statement state = null;
		try {
			System.out.println("[MySQL Connection success!]\n");
			con=database.getConnection();
			state = con.createStatement();
			Statement state2 = con.createStatement();
			
			ResultSet rs = state.executeQuery(sql);

			while (rs.next()) {
				String completedCourses = "";
				String studentId = rs.getString("studentId");
				String password = rs.getString("password");
				String studentName = rs.getString("studentName");
				String department = rs.getString("department");
				ResultSet rs2 = state2.executeQuery(completedCourseSql+" WHERE studentId = '"+studentId+"'");
				while(rs2.next()) {
					completedCourses= completedCourses+" "+rs2.getString("courseId");
				}
				Student student = new Student(studentId+" "+password+" "+studentName+" "+department+" "+completedCourses);
				arr.add(student);
				rs2.close();
			}
			rs.close();
			state.close();
			con.close();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (state != null) {
					state.close();
				}
			} catch (SQLException ex1) {

			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException ex1) {

			}
		}
		return arr;
	}

	public ArrayList<Account> getAllAccountData(String sql) {
		ArrayList<Account> arr = new ArrayList<Account>();
		Connection con = null;
		Statement state = null;
		try {
			con=database.getConnection();
			state = con.createStatement();
			
			ResultSet rs = state.executeQuery(sql);
			
			while (rs.next()) {
				String studentId = rs.getString("studentId");
				String password = rs.getString("password");
				Account account = new Account(studentId+" "+password);
				arr.add(account);
			}
			rs.close();
			state.close();
			con.close();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (state != null) {
					state.close();
				}
			} catch (SQLException ex1) {

			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException ex1) {

			}
		}
		return arr;
	}
	public void addStudent(String sql, Student student) {
		Connection con = null;
		PreparedStatement state =null;
		try {
			con=database.getConnection();
			state = con.prepareStatement(sql);
			state.setString(1,student.studentId);
			state.setString(2,student.password);
			state.setString(3,student.name);
			state.setString(4,student.department);
			int result = state.executeUpdate();
			if(result>0) {
				System.out.println("success");
			}
			String sql2="INSERT INTO completedCourse(studentId,courseId) VALUES(?,?)";
			state = con.prepareStatement(sql2);
			for(int i=0; i<student.completedCoursesList.size();i++) {
				state.setString(1,student.studentId);
				state.setString(2,student.completedCoursesList.get(i));
				int rs = state.executeUpdate();
				if(rs>0) {
					System.out.println("success");
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (state != null) {
					state.close();
				}
			} catch (SQLException ex1) {

			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException ex1) {

			}
		}
	}
	public void deleteStudent(String sql,String sql2) {
		Connection con = null;
		Statement state = null;
		try {
			con=database.getConnection();
			state = con.createStatement();
			int result = state.executeUpdate(sql);
			if(result>0) {
				System.out.println("success");
			}
			result = state.executeUpdate(sql2);
			if(result>0) {
				System.out.println("success");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (state != null) {
					state.close();
				}
			} catch (SQLException ex1) {

			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException ex1) {

			}
		}
	}
	
}

