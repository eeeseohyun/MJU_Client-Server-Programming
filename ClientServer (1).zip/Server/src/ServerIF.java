import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import javax.crypto.SecretKey;

public interface ServerIF extends Remote {
	ArrayList<Student> getAllStudentData(SecretKey requestToken) throws RemoteException,InCorrectAccessException, FileNotFoundException, IOException;
	ArrayList<Course> getAllCourseData(SecretKey requestToken) throws RemoteException,InCorrectAccessException, IOException;
	SecretKey login(SecretKey responseToken,String accountInfo)throws RemoteException, NoSuchAlgorithmException, InCorrectAccessException, IOException;
	void addStudent(SecretKey responseToken,Student student)throws RemoteException, InCorrectAccessException, IOException;
	void addCourses(SecretKey responseToken,Course course)throws RemoteException, InCorrectAccessException, IOException;
	void deleteStudent(SecretKey requestToken, String studentNum)throws RemoteException,IOException, InCorrectAccessException, InvalidRegistrationException;
	void deleteCourse(SecretKey requestToken, String courseNum)throws RemoteException,IOException, InCorrectAccessException, InvalidRegistrationException;
	void Registrate(SecretKey requestToken, RegistrateCourse registrateCourse)throws RemoteException, InCorrectAccessException, FileNotFoundException, IOException, InvalidRegistrationException;
	ArrayList<RegistrateCourse> showRegistrate(SecretKey requestToken, String studentId) throws RemoteException,InCorrectAccessException;
}