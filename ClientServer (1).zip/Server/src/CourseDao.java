import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class CourseDao {
	public DatabaseConnection database;
	public CourseDao() {
		this.database = new DatabaseConnection(); 
	}
	public ArrayList<Course> getAllCourseData(String sql,String preCourseSql){
		ArrayList<Course> arr = new ArrayList<Course>();
		Connection con = null;
		Statement state = null;
		try {
			con=database.getConnection();
			state=con.createStatement();
			state=con.createStatement();
			Statement state2 = con.createStatement();
			
			ResultSet rs = state.executeQuery(sql);
			
			while (rs.next()) {
				String preCourses = "";
				String courseId = rs.getString("courseId");
				String professorName = rs.getString("professorName");
				String courseName = rs.getString("courseName");
				ResultSet rs2 = state2.executeQuery(preCourseSql+" WHERE courseId = '"+courseId+"'");
				while(rs2.next()) {
					preCourses= preCourses+" "+rs2.getString("PrecourseId");
				}
				Course course = new Course(courseId+" "+professorName+" "+courseName+" "+preCourses);
				arr.add(course);
				rs2.close();
			}
			rs.close();
			state.close();
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (state != null) {
					state.close();
				}
			} catch (SQLException ex1) {

			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException ex1) {

			}
		}
		return arr;	
	}
	public void addCourse(String sql, Course course) {
		Connection con = null;
		PreparedStatement state = null;
		try {
			con=database.getConnection();
			state = con.prepareStatement(sql);
			state.setString(1,course.CourseID);
			state.setString(2,course.ProfessorFirstName);
			state.setString(3,course.CourseName);
			int result = state.executeUpdate();
			if(result>0) {
				System.out.println("success");
			}
			String sql2="INSERT INTO PreCourse(courseId,PrecourseId) VALUES(?,?)";
			state = con.prepareStatement(sql2);
			for(int i=0; i<course.preCourse.size();i++) {
				state.setString(1,course.CourseID);
				state.setString(2,course.preCourse.get(i));
				int rs = state.executeUpdate();
				if(rs>0) {
					System.out.println("success");
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (state != null) {
					state.close();
				}
			} catch (SQLException ex1) {

			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException ex1) {

			}
		}
	}
	
	public void deleteCourse(String sql, String sql2) {
		Connection con = null;
		Statement state = null;
		try {
			con=database.getConnection();
			state = con.createStatement();
			int result = state.executeUpdate(sql);
			if(result>0) {
				System.out.println("success");
			}
			result = state.executeUpdate(sql2);
			if(result>0) {
				System.out.println("success");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (state != null) {
					state.close();
				}
			} catch (SQLException ex1) {

			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException ex1) {

			}
		}
	}
}

