import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;


import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class Server extends UnicastRemoteObject implements ServerIF {
	
	private static final long serialVersionUID = 1L;
	public StudentDao studentdao;
	public DatabaseConnection database;
	public CourseDao coursedao;
	public RegistrateDao registratedao;
	private static SecretKey requestToken = null;
	private static StudentLogger studentLogger = StudentLogger.getLogger();
	
	protected Server() throws RemoteException {
		super();
		this.studentdao = new StudentDao();
		this.coursedao = new CourseDao();
		this.registratedao = new RegistrateDao();
	}
	
	public static void main(String[] arg) throws NotBoundException {
		try {
			Server server = new Server();
			Naming.rebind("Server", server);
			System.out.println("Server is ready !!!");
			
		} catch(RemoteException e) {
			e.printStackTrace();
		} catch(MalformedURLException e) {
			e.printStackTrace();
		}
	}
	public SecretKey login(SecretKey requestToken,String accountInfo) throws NoSuchAlgorithmException, IOException, InCorrectAccessException {
		Account account = createAccount(accountInfo);
		ArrayList<Account> accountList = getAllAccountData();
		if(!checkStudentID(account,accountList)) {
			studentLogger.log("login fail");
			throw new InCorrectAccessException("로그인 정보가 맞지 않습니다.",accountInfo);
		};
		this.requestToken = createSecretKey();
		studentLogger.setUser(account.studentId);
		studentLogger.log("login Success");
		
		return this.requestToken;
	};
	public Account createAccount(String accountInfo) throws RemoteException {
		Account account = new Account(accountInfo);
		return account;
	}
	
	public ArrayList<Account> getAllAccountData() throws IOException, InCorrectAccessException{
		ArrayList<Account> arr;
		String sql="SELECT * FROM student";
		arr = this.studentdao.getAllAccountData(sql);
		for(int i=0; i<arr.size();i++) {
			System.out.println(arr.get(i).toString());
		}
		studentLogger.log("getAllAccountData Success");
		return arr;
}
	private boolean checkStudentID(Account account, ArrayList<Account> accountList) throws RemoteException, NoSuchAlgorithmException {
		for(int i=0; i<accountList.size(); i++) {
			if(accountList.get(i).getStudentId().equals(account.getStudentId())) {
				return checkPassword(account,accountList,i);
			}
		}
		return false;
	}
	private boolean checkPassword(Account account, ArrayList<Account> accountList,int numberOfList) throws RemoteException, NoSuchAlgorithmException {
		if(accountList.get(numberOfList).getPassword().equals(account.getPassword())) {
			return true;
		}
		return false;
	}

	public SecretKey createSecretKey() throws RemoteException, NoSuchAlgorithmException{
		SecretKey secretkey= SecretKey();
		studentLogger.log("crateToken success");
		return secretkey;
	}
	private SecretKey SecretKey() throws RemoteException, NoSuchAlgorithmException{
		KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(256); // 키 길이 선택 (128, 192, 256 중 선택)
        SecretKey secretKey = keyGenerator.generateKey();
        return secretKey;
	}
	public ArrayList<Student> getAllStudentData(SecretKey requestToken) throws InCorrectAccessException, FileNotFoundException, IOException {
		ArrayList<Student> arr;
		if(checkToken(requestToken)) {
			String studentsql="SELECT * FROM Student";
			String completedCourseSql ="SELECT * FROM completedcourse";
			arr = this.studentdao.getAllStudentData(studentsql,completedCourseSql);
			studentLogger.log("getAllStudentData Success");
			return arr;
		}else {
			studentLogger.log("getAllStudentData Fail");
			throw new InCorrectAccessException("올바른 account가 아닙니다.");
		}
	}
	public ArrayList<Course> getAllCourseData(SecretKey requestToken) throws InCorrectAccessException, IOException{
		ArrayList<Course> arr;
		if(checkToken(requestToken)) {
			String courseSql ="SELECT * FROM Course";
			String preCourseSql="SELECT * FROM preCourse";
			arr = this.coursedao.getAllCourseData(courseSql, preCourseSql);
			studentLogger.log("getAllCourseData Success");
			return arr;
		}else {
			studentLogger.log("getAllCourseData Fail");
			throw new InCorrectAccessException("올바른 account가 아닙니다.");
		}
	}
	private boolean checkToken(SecretKey responseToken) {
		byte[] requestTokenByte = this.requestToken.getEncoded();
		byte[] responseTokenByte= responseToken.getEncoded();
		if(Arrays.equals(responseTokenByte, requestTokenByte)){
			return true;
		}
		return false;
	}
	

	public void addStudent(SecretKey responseToken, Student student) throws InCorrectAccessException, IOException {
		if(checkToken(responseToken)) {
			String sql="INSERT INTO student (studentId,password,studentName,department) VALUES (?,?,?,?)";		
			studentdao.addStudent(sql,student);
			studentLogger.log("addStudent Success");
		}else {
			studentLogger.log("addStudent Fail");
			throw new InCorrectAccessException("올바른 account가 아닙니다.");
		}
	}
	public void addCourses(SecretKey responseToken, Course course)throws RemoteException, InCorrectAccessException, IOException {
		if(checkToken(responseToken)) {
			String sql="INSERT INTO course (courseId,professorName,CourseName) VALUES (?,?,?)";		
			coursedao.addCourse(sql,course);
			studentLogger.log("addCourse Success");
		}else {
			studentLogger.log("addCourse Fail");
			throw new InCorrectAccessException("올바른 account가 아닙니다.");
		}
		
	}

	public void deleteStudent(javax.crypto.SecretKey requestToken, String studentNum) throws RemoteException, IOException, InCorrectAccessException, InvalidRegistrationException {
		
		if(!checkToken(requestToken)) {
			studentLogger.log("deleteStudent Fail");
			throw new InCorrectAccessException("올바른 account가 아닙니다.");
		}else if(!checkTrueStudent(requestToken,studentNum)){
			throw new InvalidRegistrationException("존재하지 않는 ID입니다.",studentNum);
		}
		else{
			String sql2="DELETE FROM student WHERE studentId = "+'"'+studentNum+'"';
			String sql="DELETE FROM completedcourse WHERE studentId = "+'\"'+studentNum+'"';
			studentdao.deleteStudent(sql,sql2);
			studentLogger.log("deleteStudent Success");
		}
	}
	public boolean checkTrueStudent(javax.crypto.SecretKey requestToken,String studentId) throws FileNotFoundException, InCorrectAccessException, IOException {
		ArrayList<Student> AllStudentList;
		
		AllStudentList=getAllStudentData(requestToken);
		for(int i=0; i<AllStudentList.size();i++) {
			if(AllStudentList.get(i).studentId.equals(studentId)) {
				return true;
			}
		}
		return false;
	}
	public void deleteCourse(javax.crypto.SecretKey requestToken, String courseNum) throws RemoteException, IOException, InCorrectAccessException, InvalidRegistrationException {
		if(!checkToken(requestToken)) {
			studentLogger.log("deleteCourse Fail");
			throw new InCorrectAccessException("올바른 account가 아닙니다.");
		}else if(!checkTrueCourse(requestToken,courseNum)) {
			throw new InvalidRegistrationException("존재하지 않는 ID입니다.",courseNum);
		}else {
			String sql2="DELETE FROM course WHERE courseId = "+'"'+courseNum+'"';
			String sql="DELETE FROM precourse WHERE courseId = "+'"'+courseNum+'"';
			coursedao.deleteCourse(sql,sql2);
			studentLogger.log("deleteCourse success");
		}
		
	}
	public boolean checkTrueCourse(javax.crypto.SecretKey requestToken,String courseId) throws InCorrectAccessException, IOException {
		ArrayList<Course> AllCourseList;
		AllCourseList=getAllCourseData(requestToken);
		for(int i=0; i<AllCourseList.size();i++) {
			if(AllCourseList.get(i).CourseID.equals(courseId)) {
				return true;
			}
		}
		return false;
	}
	public boolean checkPreCourse(javax.crypto.SecretKey requestToken,RegistrateCourse registrateCourse) throws InCorrectAccessException, IOException {
		ArrayList<Course> AllCourseList;
		ArrayList<String> PreCourseList;
		ArrayList<Student> AllStudentList;
		ArrayList<String> CompletedCourseList;
		AllCourseList=getAllCourseData(requestToken);
		int numberOfCourse=0;
		int numberOfStudent=0;
		for(int i=0; i<AllCourseList.size();i++) {
			if(AllCourseList.get(i).CourseID.equals(registrateCourse.courseId)) {
				numberOfCourse=i;
			}
		}
		PreCourseList=AllCourseList.get(numberOfCourse).preCourse;
		AllStudentList =getAllStudentData(requestToken);
		for(int i=0; i<AllStudentList.size();i++) {
			if(AllStudentList.get(i).studentId.equals(registrateCourse.studentId)) {
				numberOfStudent=i;
			}
		}
		CompletedCourseList = AllStudentList.get(numberOfStudent).completedCoursesList;
		
		for(int i=0; i<PreCourseList.size();i++) {
			if(!CompletedCourseList.contains(PreCourseList.get(i))) {
				return false;
			}
		}
		return true;
	}
	public void Registrate(javax.crypto.SecretKey requestToken, RegistrateCourse registrateCourse)throws InCorrectAccessException, FileNotFoundException, IOException, InvalidRegistrationException {
		if(!checkToken(requestToken)) {
			studentLogger.log("Registrate Fail");
			throw new InCorrectAccessException("올바른 account가 아닙니다.");
		}else if(!checkTrueStudent(requestToken,registrateCourse.studentId)) {
			studentLogger.log("Registrate Fail");
			throw new InvalidRegistrationException("존재하지 않는 studentId 입니다.",registrateCourse.studentId);
		}else if(!checkTrueCourse(requestToken,registrateCourse.courseId)) {
			studentLogger.log("Registrate Fail");
			throw new InvalidRegistrationException("존재하지 않는 CourseId 입니다.",registrateCourse.courseId);
		}else if(!checkPreCourse(requestToken,registrateCourse)) {
			studentLogger.log("Registrate Fail");
			throw new InvalidRegistrationException("선수과목을 확인해주세요.",registrateCourse.courseId);
		}else {
			String sql="INSERT INTO registratedCourse (studentId,courseId) VALUES (?,?)";
			registratedao.RegistrateCourse(sql,registrateCourse);
			studentLogger.log("Registrate Success");
		}
		
	}

	public ArrayList<RegistrateCourse> showRegistrate(javax.crypto.SecretKey requestToken, String studentId) throws InCorrectAccessException {
		ArrayList<RegistrateCourse> registrateCourse;
		if(checkToken(requestToken)) {
			String courseSql ="SELECT * FROM RegistratedCourse WHERE studentId="+'"'+studentId+'"';
			registrateCourse = this.registratedao.getAllRegistratedData(courseSql);
			return registrateCourse;
		}else {
			throw new InCorrectAccessException("로그인 정보가 맞지 않습니다.");
		}
	}

	

}
