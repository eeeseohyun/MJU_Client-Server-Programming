import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class StudentLogger {
	Logger logger = Logger.getLogger("MyLogger");
	private static StudentLogger instance = new StudentLogger();
	public static final String logFileName="src/log.txt";
	private static String userId=null;
	private FileHandler logFile=null;

	StudentLogger() {
		try {
			logFile = new FileHandler(logFileName,false);
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		logFile.setFormatter(new SimpleFormatter());
		logFile.setLevel(Level.ALL);
		
		logger.addHandler(logFile);
	}
	public static StudentLogger getLogger() {
		return instance;
	}
	public void log(String commandType) {
		long timestamp = System.currentTimeMillis();
		logger.info(userId+ " - " + commandType + " - " + timestamp);
	}
	public void setUser(String studentId) {
		this.userId = studentId;
	}
}
