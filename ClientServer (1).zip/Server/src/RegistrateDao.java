
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class RegistrateDao {
	public DatabaseConnection database;
	public RegistrateDao() {
		this.database = new DatabaseConnection(); 
	}
	public void RegistrateCourse(String sql, RegistrateCourse registrateCourse) {
		Connection con = null;
		PreparedStatement state = null;
		try {
			con=database.getConnection();
			state = con.prepareStatement(sql);
			state.setString(1,registrateCourse.studentId);
			state.setString(2,registrateCourse.courseId);
			int result = state.executeUpdate();
			if(result>0) {
				System.out.println("success");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (state != null) {
					state.close();
				}
			} catch (SQLException ex1) {

			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException ex1) {

			}
		}
		
	}
	public ArrayList<RegistrateCourse> getAllRegistratedData(String sql) {
		ArrayList<RegistrateCourse> arr = new ArrayList<RegistrateCourse>();
		Connection con = null;
		Statement state = null;
		try {
			con=database.getConnection();
			state = con.createStatement();
			
			ResultSet rs = state.executeQuery(sql);
			
			while (rs.next()) {
				String studentId = rs.getString("studentId");
				String courseId = rs.getString("courseId");
				RegistrateCourse registrateCourse = new RegistrateCourse(studentId+" "+courseId);
				arr.add(registrateCourse);
			}
			rs.close();
			state.close();
			con.close();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (state != null) {
					state.close();
				}
			} catch (SQLException ex1) {

			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException ex1) {

			}
		}
		return arr;
	}
	
}

