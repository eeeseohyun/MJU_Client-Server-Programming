import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ServerIF extends Remote {
	void save (String name ) throws RemoteException;
	String read() throws RemoteException;
}