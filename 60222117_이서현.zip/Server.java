import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Server extends UnicastRemoteObject implements ServerIF {
	String name;

	protected Server() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Server server = new Server();
			Naming.rebind("saveName", server);
			Naming.rebind("receiveName", server);
			System.out.println("Server is ready !!!");
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void save(String name) throws RemoteException {
		System.out.println("send name: "+name);
		this.name = name;
	}

	@Override
	public String read() throws RemoteException {
		System.out.println("receive name: "+this.name);
		return name;
		// TODO Auto-generated method stub
		
	}

}
