import java.io.Serializable;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Course implements Serializable{
	private static final long serialVersionUID = 1L;
	protected String CourseID;
	protected String ProfessorFirstName;
	protected String CourseName;
	protected ArrayList<String> Students;
	
	public Course(String inputString){
		StringTokenizer stringTokenizer = new StringTokenizer(inputString);
		this.CourseID = stringTokenizer.nextToken();
		this.ProfessorFirstName =stringTokenizer.nextToken();
		this.CourseName = stringTokenizer.nextToken();
		this.Students = new ArrayList<String>();
		while(stringTokenizer.hasMoreTokens()) {
			this.Students.add(stringTokenizer.nextToken());
		}
	}
	public ArrayList<String> getAllCourse(){
		return this.Students;
	}
}
