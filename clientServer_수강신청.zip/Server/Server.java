import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class Server extends UnicastRemoteObject implements ServerIF {
	
	private static final long serialVersionUID = 1L;
	private static DataIF data;
	private static byte[] requestToken = null;
	protected Server() throws RemoteException {
		super();
	}
	
	public static void main(String[] arg) throws NotBoundException {
		try {
			Server server = new Server();
			Naming.rebind("Server", server);
			System.out.println("Server is ready !!!");
			
			data =(DataIF)Naming.lookup("Data");
		} catch(RemoteException e) {
			e.printStackTrace();
		} catch(MalformedURLException e) {
			e.printStackTrace();
		} 
	}
	
	public ArrayList<Student> getAllStudentData() throws RemoteException {
		return data.getAllStudentData();
	}
	public ArrayList<Course> getAllCourseData() throws RemoteException{
		return data.getAllCourseData();
	}
	public ArrayList<Account> getAllAccountData() throws RemoteException{
		return data.getAllAccountData();
	}
	public byte[] createRequestSecretKey() throws RemoteException, NoSuchAlgorithmException{
		SecretKey secretkey= SecretKey();
		Server.requestToken = secretkey.getEncoded();
		return Server.requestToken;
	}
	public byte[] createSecretKey() throws RemoteException, NoSuchAlgorithmException{
		SecretKey secretkey= SecretKey();
		byte[] Token = secretkey.getEncoded();
		return Token;
	}
	private SecretKey SecretKey() throws RemoteException, NoSuchAlgorithmException{
		KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(256); // 키 길이 선택 (128, 192, 256 중 선택)
        SecretKey secretKey = keyGenerator.generateKey();
        return secretKey;
	}
	public byte[] login(String accountInfo) throws RemoteException, NoSuchAlgorithmException {
		// TODO Auto-generated method stub
		Account account = createAccount(accountInfo);
		ArrayList<Account> accountList = getAllAccountData();
		byte[] ResponseToken = checkAccount(account,accountList);
		Log(ResponseToken,account);
		return ResponseToken;
	};
	private void Log(byte[] responseToken, Account account) {
		if(checkToken(responseToken)) {
			try {
				data.log(account.studentId);
				System.out.println("log");
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	private boolean checkToken(byte[] responseToken) {
		if(Arrays.equals(responseToken, requestToken)){
			return true;
		}
		return false;
	}
	public Account createAccount(String accountInfo) throws RemoteException {
		Account account = new Account(accountInfo);
		return account;
	}
	private byte[] checkAccount(Account account, ArrayList<Account> accountList) throws RemoteException, NoSuchAlgorithmException {
		// TODO Auto-generated method stub
		byte[] token=checkStudentID(account,accountList);
		return token;
	}
	private byte [] checkStudentID(Account account, ArrayList<Account> accountList) throws RemoteException, NoSuchAlgorithmException {
		// TODO Auto-generated method stub
		for(int i=0; i<accountList.size(); i++) {
			if(accountList.get(i).getStudentId().equals(account.getStudentId())) {
				return checkPassword(account,accountList,i);
			}
		}
		return createSecretKey();
	}
	private byte[] checkPassword(Account account, ArrayList<Account> accountList,int numberOfList) throws RemoteException, NoSuchAlgorithmException {
		// TODO Auto-generated method stub
		if(accountList.get(numberOfList).getPassword().equals(account.getPassword())) {
			return requestToken;
		}
		return createSecretKey();
	}

}
