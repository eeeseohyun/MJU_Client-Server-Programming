import java.io.Serializable;
import java.util.StringTokenizer;

public class Account implements Serializable {
	private static final long serialVersionUID = 1L;
	protected String studentId;
	protected String password;
	
	public Account(String inputString) {
		StringTokenizer stringTokenizer = new StringTokenizer(inputString);
    	this.studentId = stringTokenizer.nextToken();
    	this.password = stringTokenizer.nextToken();
	}
	public String toString() {
		String stringReturn = this.studentId + " " + this.password;
		return stringReturn;
	}
	public String getStudentId() {
		return this.studentId;
	}
	public String getPassword() {
		return this.password;
	}
}
