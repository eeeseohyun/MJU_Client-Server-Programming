import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class Client {
	private static BufferedReader objReader = new BufferedReader(new InputStreamReader(System.in));
	private static byte[] RequestToken = null;
	public static void main(String[] args) throws IOException {
		ServerIF server;
		try {
			server = (ServerIF)Naming.lookup("Server");
			printmain();
			String sChoice= objReader.readLine().trim();
			checkMainMenuNumber(server, sChoice);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (NotBoundException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
	}
	private static void checkMainMenuNumber(ServerIF server,String sChoice) throws IOException, NoSuchAlgorithmException {
		if(sChoice.equals("1")) {
			RequestToken =server.createRequestSecretKey();
			login(server,RequestToken);
		}else{
			printError();
			reLogin(server);
		}
	}
	private static void printError(){
		System.out.println("잘못된 값을 입력하셨습니다.");
		System.out.println("다시 시도하세요.");
	}
	private static void reLogin(ServerIF server) throws NoSuchAlgorithmException, IOException {
		printmain();
		String Choice= objReader.readLine().trim();
		checkMainMenuNumber(server, Choice);
	}
	private static void printmain() {
		System.out.println("***************** MENU *****************");
		System.out.println("1. login");
	}

	private static void login(ServerIF server, byte[] requestToken) throws IOException, NoSuchAlgorithmException {
		printLogin();
		String accountInfo = inputAccountData();
		byte[] ResponseToken = server.login(accountInfo);
		if(Arrays.equals(ResponseToken, RequestToken)) {
			look(server);
		}else {
			printError();
			reLogin(server);
		}
	}
	private static void printLogin() {
		System.out.println("학번과 비밀번호를 입력하세요");
		System.out.print("학번: ");
	}
	private static String inputAccountData() throws IOException {
		String studentID= objReader.readLine().trim();
		System.out.print("비밀번호: ");
		String password= objReader.readLine().trim();
		String accountInfo = studentID+" "+password;
		return accountInfo;
		
	}

	public static void look(ServerIF server) throws IOException {
		printLook();
		String choice = objReader.readLine().trim();
		while(choice!=null) {
			checkLookMenuNumber(server, choice);
			printLook();
			choice = objReader.readLine().trim();
		}
	
	}
	public static void printLook() {
		System.out.println("***************** MENU *****************");
		System.out.println("1. List Students");
		System.out.println("2. List Courses");
	}
	private static void checkLookMenuNumber(ServerIF server,String sChoice) throws IOException {
		if(sChoice.equals("1")) {
			lookStudents(server);
		}else if(sChoice.equals("2")) {
			lookCourses(server);
		}else {
			printError();
			reLook(server);
		}
		
	}
	private static void reLook(ServerIF server) throws IOException {
		printLook();
		String Choice= objReader.readLine().trim();
		checkLookMenuNumber(server, Choice);
	}
	private static void lookCourses(ServerIF server) throws RemoteException {
		// TODO Auto-generated method stub
		System.out.println("List Courses : " + server.getAllCourseData());
	}
	private static void lookStudents(ServerIF server) throws RemoteException {
		// TODO Auto-generated method stub
		System.out.println("List Students : " + server.getAllStudentData());
	}

}
