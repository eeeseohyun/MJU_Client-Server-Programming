import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class StudentLogger {
	Logger logger = Logger.getLogger("StudentLogger");
	private static StudentLogger instance = new StudentLogger();
	public static final String logFileName="/Users/User/eclipse-workspace/Data/src/log.txt";
	private static final String commandType ="LOGIN";
	
	private FileHandler logFile=null;

	private StudentLogger() {
		try {
			logFile = new FileHandler(logFileName,true);
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		logFile.setFormatter(new SimpleFormatter());
		logFile.setLevel(Level.ALL);
		
		logger.addHandler(logFile);
	}
	public static StudentLogger getLogger() {
		return instance;
	}
	public void log(String studentId) {
		long timestamp = System.currentTimeMillis();
		logger.info(studentId+ " - " + commandType + " - " + timestamp);
	}
}
