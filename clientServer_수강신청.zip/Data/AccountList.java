import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class AccountList {
	protected ArrayList<Account> vAccount;
	
	public AccountList(String sAccountFileName) throws IOException {
		BufferedReader objAccountFile = new BufferedReader(new FileReader(sAccountFileName));
		this.vAccount = new ArrayList<Account>();
		while(objAccountFile.ready()) {
			String AccountInfo = objAccountFile.readLine();
			if(!AccountInfo.equals("")) {
				this.vAccount.add(new Account(AccountInfo));
			}
		}
		objAccountFile.close();
	}
	public ArrayList<Account> getAllAccountRecords() {
		// TODO Auto-generated method stub
		return vAccount;
	}
	
}
