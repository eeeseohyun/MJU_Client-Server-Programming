import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CourseList {
	protected ArrayList<Course> vCourse;
	
	public CourseList(String sCourseFileName) throws IOException {
		BufferedReader objCourseFile = new BufferedReader(new FileReader(sCourseFileName));
		this.vCourse = new ArrayList<Course>();
		while(objCourseFile.ready()) {
			String CourseInfo = objCourseFile.readLine();
			if(!CourseInfo.equals("")) {
				this.vCourse.add(new Course(CourseInfo));
			}
		}
		objCourseFile.close();
	}

	public ArrayList<Course> getAllCourseRecords() {
		// TODO Auto-generated method stub
		return this.vCourse;
	}
}
