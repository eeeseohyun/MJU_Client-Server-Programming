import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

public class Data extends UnicastRemoteObject implements DataIF {
	private static final long serialVersionUID = 1L;
	protected static StudentList studentList;
	protected static CourseList courseList;
	public static AccountList accountList;
	protected Data() throws RemoteException {
		super();
	}
	
	public static void main(String[] arg) throws FileNotFoundException, IOException {
		try {
			Data data = new Data();
			Naming.rebind("Data", data);
			System.out.println("Data is ready !!!");
			
			studentList = new StudentList("src/Students.txt");
			courseList = new CourseList("src/Courses.txt");
			accountList = new AccountList("src/Students.txt");
		} catch(RemoteException e) {
			e.printStackTrace();
		} catch(MalformedURLException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<Student> getAllStudentData() throws RemoteException {
		// TODO Auto-generated method stub
		return studentList.getAllStudentRecords();
	}
	public ArrayList<Course> getAllCourseData() throws RemoteException{
		return courseList.getAllCourseRecords();
	}
	public ArrayList<Account> getAllAccountData() throws RemoteException{
		return accountList.getAllAccountRecords();
	}
	public void log(String studentId) throws RemoteException{
		StudentLogger studentLogger = StudentLogger.getLogger();
		studentLogger.log(studentId);
		System.out.println("log finish");
	}

}
